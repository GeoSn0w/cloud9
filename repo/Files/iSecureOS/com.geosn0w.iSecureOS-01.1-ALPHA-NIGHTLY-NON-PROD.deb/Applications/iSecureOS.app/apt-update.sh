#!/bin/bash
apt-get upgrade -s | grep upgraded | cut -d ' ' -f 1

